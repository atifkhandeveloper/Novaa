package sabeeldev.creativegarage.mivida

import java.io.IOException


class APIException(message: String) : IOException(message.toString())