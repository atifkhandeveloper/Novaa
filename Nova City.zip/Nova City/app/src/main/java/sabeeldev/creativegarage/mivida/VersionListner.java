package sabeeldev.creativegarage.mivida;

public interface VersionListner {

    void onVersionReceived(String versionCode);
}
