package sabeeldev.creativegarage.mivida.network

object Urls {
    const val BASE_URL = "https://mividapakistan.pk/mv/web/tcpdf/print/"
    const val OTP_SEND = "test_otp_submit_copy1.php?"
}


