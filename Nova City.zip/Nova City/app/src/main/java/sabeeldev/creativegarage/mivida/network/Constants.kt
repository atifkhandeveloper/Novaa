package sabeeldev.creativegarage.mivida.network

object Constants {
   const val  CURRENT_VERSION = 1

    const val TRADE_SUCCESS = "Trade Successfully"
    const val OTP_SEND = "OTP Send to your Registered Phone #"
    const val SEC_CODE_ERROR = "Security Code is not Available"
    const val MOBILE_NO_ERROR = "Please enter Correct Contact # (03XXXXXXXXX)"
    const val OTP_SEND_NEW = "OTP Send to your New Phone #"
    const val API_KEY = "tg4hhZ4zs+/GJ03sRcfgD9thGa7GYjXtdFQxbtFvs58="
    var VERIFY_URL="https://mividapakistan.pk/mv/web/tcpdf/print/generated_form_search1.php?id="
    var back_stack = "";
    var back_status=false;
    var OTP_VERIFIED=false;
}