package sabeeldev.creativegarage.mivida.Fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import sabeeldev.creativegarage.mivida.MyBrowser
import sabeeldev.creativegarage.mivida.R
import sabeeldev.creativegarage.mivida.databinding.FragmentContactBinding
import sabeeldev.creativegarage.mivida.databinding.FragmentHomeBinding


class ContactFragment : Fragment() {

    private lateinit var binding: FragmentContactBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_contact, container, false)
        loadWebView()
        return binding.root
    }

    private fun loadWebView() {
        binding.webviewContact.webViewClient = MyBrowser()
        binding.webviewContact.settings.loadsImagesAutomatically = true;
        binding.webviewContact.settings.javaScriptEnabled = true;
        binding.webviewContact.scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY;
        binding.webviewContact.loadUrl("https://www.google.com/maps/place/MIVIDA+Pakistan+Corporate+Office/@33.668645,72.999009,18z/data=!4m5!3m4!1s0x0:0x2e41c2d0094f07e9!8m2!3d33.6686445!4d72.9990086?hl=en-US");
    }

}