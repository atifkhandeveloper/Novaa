package sabeeldev.creativegarage.mivida;

public interface onResult {

    void onResultReceived(String error,String message);
}
