package sabeeldev.creativegarage.mivida

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Html
import dev.shreyaspatil.MaterialDialog.AbstractDialog
import dev.shreyaspatil.MaterialDialog.BottomSheetMaterialDialog

class LoginResultActivity : AppCompatActivity() {
    private var mSuccess: BottomSheetMaterialDialog? = null
    private var mError: BottomSheetMaterialDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_result)
    }


}