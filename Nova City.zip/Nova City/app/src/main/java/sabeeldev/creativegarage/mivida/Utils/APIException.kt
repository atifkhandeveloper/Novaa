package sabeeldev.creativegarage.mivida.Utils

import java.io.IOException

class APIException(message: String) : IOException(message)
