package sabeeldev.creativegarage.mivida;

import android.content.Context;

public class Network {
    private Context context;

    public Network(Context context) {
        this.context = context;
    }


}
